"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var electron_1 = require("electron");
var huobi_helper_1 = require("./huobi-helper");
var cexio_helper_1 = require("./cexio-helper");
var bittrex_helper_1 = require("./bittrex-helper");
var zb_helper_1 = require("./zb-helper");
var path = require("path");
var fs = require("fs");
var axios_1 = require("axios");
var CryptoJS = require("crypto-js");
var qs = require("qs");
var utf8 = require("utf8");
var crypto = require('crypto');
if (handleSquirrelWinEvent(electron_1.app)) {
    // squirrel event handled and app will exit in 1000ms, so don't do anything else
    // return;
}
// Initialize remote module
require('@electron/remote/main').initialize();
var win = null;
var args = process.argv.slice(1), serve = args.some(function (val) { return val === '--serve'; });
function loadViewFromFile() {
    var pathIndex = './index.html';
    if (fs.existsSync(path.join(__dirname, '../dist/index.html'))) {
        // Path when running electron in local folder
        pathIndex = '../dist/index.html';
    }
    win.loadFile(path.join(__dirname, pathIndex));
}
function createWindow() {
    var electronScreen = electron_1.screen;
    var size = electronScreen.getPrimaryDisplay().workAreaSize;
    // Create the browser window.
    win = new electron_1.BrowserWindow({
        x: 0,
        y: 0,
        width: size.width,
        height: size.height,
        webPreferences: {
            //webSecurity: false,
            nodeIntegration: true,
            allowRunningInsecureContent: (serve) ? true : false,
            contextIsolation: false,
            enableRemoteModule: true // true if you want to run 2e2 test  with Spectron or use remote module in renderer context (ie. Angular)
        },
    });
    /*const items: MenuItem[] = [];
    const menu = Menu.buildFromTemplate(items);
    Menu.setApplicationMenu(menu);
*/
    if (serve) {
        win.webContents.openDevTools();
        require('electron-reload')(__dirname, {
            electron: require(path.join(__dirname, '/../node_modules/electron'))
        });
        win.loadURL('http://localhost:4200');
    }
    else {
        // Path when running electron executable
        loadViewFromFile();
    }
    // Emitted when the window is closed.
    win.on('closed', function () {
        // Dereference the window object, usually you would store window
        // in an array if your app supports multi windows, this is the time
        // when you should delete the corresponding element.
        bittrex_helper_1.closeBittrex();
        cexio_helper_1.closeCexio();
        win = null;
    });
    win.webContents.on('did-fail-load', function () {
        loadViewFromFile();
    });
    return win;
}
function handleSquirrelWinEvent(application) {
    if (process.argv.length === 1) {
        return false;
    }
    var ChildProcess = require('child_process');
    var path = require('path');
    var appFolder = path.resolve(process.execPath, '..');
    var rootAtomFolder = path.resolve(appFolder, '..');
    var updateDotExe = path.resolve(path.join(rootAtomFolder, 'Update.exe'));
    var exeName = path.basename(process.execPath);
    var spawn = function (command, args) {
        var spawnedProcess, error;
        try {
            spawnedProcess = ChildProcess.spawn(command, args, {
                detached: true
            });
        }
        catch (error) { }
        return spawnedProcess;
    };
    var spawnUpdate = function (args) {
        return spawn(updateDotExe, args);
    };
    var squirrelEvent = process.argv[1];
    switch (squirrelEvent) {
        case '--squirrel-install':
        case '--squirrel-updated':
            // Optionally do things such as:
            // - Add your .exe to the PATH
            // - Write to the registry for things like file associations and
            //   explorer context menus
            // Install desktop and start menu shortcuts
            spawnUpdate(['--createShortcut', exeName]);
            setTimeout(application.quit, 1000);
            return true;
        case '--squirrel-uninstall':
            // Undo anything you did in the --squirrel-install and
            // --squirrel-updated handlers
            // Remove desktop and start menu shortcuts
            spawnUpdate(['--removeShortcut', exeName]);
            setTimeout(application.quit, 1000);
            return true;
        case '--squirrel-obsolete':
            // This is called on the outgoing version of your app before
            // we update to the new version - it's the opposite of
            // --squirrel-updated
            application.quit();
            return true;
    }
}
try {
    // This method will be called when Electron has finished
    // initialization and is ready to create browser windows.
    // Some APIs can only be used after this event occurs.
    // Added 400 ms to fix the black background issue while using transparent window.
    // More details at https://github.com/electron/electron/issues/15947
    electron_1.app.on('ready', function () { return setTimeout(createWindow, 400); });
    // Quit when all windows are closed.
    electron_1.app.on('window-all-closed', function () {
        // On OS X it is common for applications and their menu bar
        // to stay active until the user quits explicitly with Cmd + Q
        if (process.platform !== 'darwin') {
            //app.quit();
        }
        electron_1.app.quit();
    });
    electron_1.app.on('activate', function () {
        // On OS X it's common to re-create a window in the app when the
        // dock icon is clicked and there are no other windows open.
        if (win === null) {
            createWindow();
        }
    });
}
catch (e) {
    // Catch Error
    // throw e;
}
electron_1.ipcMain.handle('request', function (_, axios_request) { return __awaiter(void 0, void 0, void 0, function () {
    var result, e_1, errMsg;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, 3, 4]);
                if (axios_request.headers && axios_request.headers['API-Sign']) {
                    axios_request.data = qs.stringify(axios_request.data);
                }
                return [4 /*yield*/, axios_1.default(axios_request)];
            case 1:
                result = _a.sent();
                return [2 /*return*/, { data: result.data, status: result.status }];
            case 2:
                e_1 = _a.sent();
                console.error('starting finished with error ', e_1);
                errMsg = void 0;
                if (e_1.response && e_1.response.data) {
                    if (e_1.response.data.detail) {
                        errMsg = e_1.response.data.detail;
                    }
                    else if (e_1.response.data.message) {
                        errMsg = e_1.response.data.message;
                    }
                    else if (e_1.response.data.msg) {
                        errMsg = e_1.response.data.msg;
                    }
                    else {
                        if (e_1.response.data.code) {
                            errMsg = e_1.response.data;
                        }
                    }
                }
                if (!errMsg) {
                    if (e_1.message) {
                        errMsg = e_1.message;
                    }
                    else {
                        if (typeof e_1 === 'string' || e_1 instanceof String) {
                            errMsg = e_1;
                        }
                        else {
                            errMsg = JSON.stringify(e_1);
                        }
                    }
                }
                return [2 /*return*/, { error: errMsg }];
            case 3: return [7 /*endfinally*/];
            case 4: return [2 /*return*/];
        }
    });
}); });
electron_1.ipcMain.handle('bitfinexAuth', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        try {
            if (data.isHex) {
                return [2 /*return*/, CryptoJS.HmacSHA384(data.authPayload, data.secretKey).toString(CryptoJS.enc.Hex)];
            }
            return [2 /*return*/, CryptoJS.HmacSHA384(data.authPayload, data.secretKey).toString()];
        }
        catch (e) {
            console.error('bitfinexAuth finished with error', e);
            return [2 /*return*/, { error: e, status: 500 }];
        }
        finally {
            console.log('finalizing bitfinexAuth');
        }
        return [2 /*return*/];
    });
}); });
electron_1.ipcMain.handle('krakenSignature', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    var message, secret_buffer, hash, hmac, hash_digest, hmac_digest;
    return __generator(this, function (_a) {
        try {
            message = qs.stringify(data.params);
            secret_buffer = Buffer.from(data.secretKey, 'base64');
            hash = new crypto.createHash('sha256');
            hmac = new crypto.createHmac('sha512', secret_buffer);
            hash_digest = hash.update(data.params.nonce + message).digest('binary');
            hmac_digest = hmac.update(data.path + hash_digest, 'binary').digest('base64');
            return [2 /*return*/, hmac_digest];
        }
        catch (e) {
            console.error('krakenSignature finished with error ', e);
            return [2 /*return*/, { error: e }];
        }
        finally {
            console.log('finalizing krakenSignature');
        }
        return [2 /*return*/];
    });
}); });
electron_1.ipcMain.handle('binanceSignature', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    var hmac;
    return __generator(this, function (_a) {
        try {
            hmac = new crypto.createHmac('sha256', data.secretKey);
            return [2 /*return*/, hmac.update(data.authPayload).digest('hex')];
        }
        catch (e) {
            console.error('binanceSignature finished with error ', e);
            return [2 /*return*/, { error: e }];
        }
        finally {
            console.log('finalizing binanceSignature');
        }
        return [2 /*return*/];
    });
}); });
electron_1.ipcMain.handle('bithumbSignature', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        try {
            return [2 /*return*/, crypto.createHmac('sha256', data.secretKey)
                    .update(utf8.encode(data.msg))
                    .digest('hex')];
        }
        catch (e) {
            console.error('starting finished with error ', e);
            return [2 /*return*/, { error: e }];
        }
        finally {
        }
        return [2 /*return*/];
    });
}); });
/*huobi*/
electron_1.ipcMain.handle('houbiSignature', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    var method, fullURL, accessKey, secretKey, dataInfo;
    return __generator(this, function (_a) {
        try {
            method = data.method;
            fullURL = data.fullURL;
            accessKey = data.accessKey;
            secretKey = data.secretKey;
            dataInfo = data.data;
            return [2 /*return*/, huobi_helper_1.signature_Huobi(method, fullURL, accessKey, secretKey, dataInfo)];
        }
        catch (e) {
            console.error('starting finished with error ', e);
            return [2 /*return*/, { error: e }];
        }
        finally {
        }
        return [2 /*return*/];
    });
}); });
electron_1.ipcMain.handle('houbiWsSignature', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    var method, wsURL, accessKey, secretKey;
    return __generator(this, function (_a) {
        try {
            method = data.method;
            wsURL = data.wsURL;
            accessKey = data.accessKey;
            secretKey = data.secretKey;
            return [2 /*return*/, huobi_helper_1.signature_V2_Huobi(method, wsURL, accessKey, secretKey)];
        }
        catch (e) {
            console.error('starting finished with error ', e);
            return [2 /*return*/, { error: e }];
        }
        finally {
        }
        return [2 /*return*/];
    });
}); });
/* //houbi */
/* cexio */
electron_1.ipcMain.handle('cexioSignature', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        return [2 /*return*/, cexio_helper_1.signature_Cexio(data)];
    });
}); });
electron_1.ipcMain.handle('connectCexio', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, cexio_helper_1.wsCexioConnect(data.wsUrl)];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); });
function cexOpenOrdersHandler(data) {
    win.webContents.send('cexio-open-orders', data);
}
function cexBalanceHandler(data) {
    win.webContents.send('cexio-get-balance', data);
}
function cexPlaceOrderHandler(data) {
    win.webContents.send('cexio-place-order', data);
}
function cexCancelOrderHandler(data) {
    win.webContents.send('cexio-cancel-order', data);
}
function cexNewTradeHandler(data) {
    win.webContents.send('cexio-new-trade', data);
}
function cexAuthHandler(data) {
    win.webContents.send('cexio-auth', data);
}
electron_1.ipcMain.handle('authenticateCexio', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        try {
            cexio_helper_1.cexioEmitter.off('open-orders', cexOpenOrdersHandler);
            cexio_helper_1.cexioEmitter.off('get-balance', cexBalanceHandler);
            cexio_helper_1.cexioEmitter.off('place-order', cexPlaceOrderHandler);
            cexio_helper_1.cexioEmitter.off('cancel-order', cexCancelOrderHandler);
            cexio_helper_1.cexioEmitter.off('new-trade', cexNewTradeHandler);
            cexio_helper_1.cexioEmitter.off('auth', cexAuthHandler);
            cexio_helper_1.cexioEmitter.on('open-orders', cexOpenOrdersHandler);
            cexio_helper_1.cexioEmitter.on('get-balance', cexBalanceHandler);
            cexio_helper_1.cexioEmitter.on('place-order', cexPlaceOrderHandler);
            cexio_helper_1.cexioEmitter.on('cancel-order', cexCancelOrderHandler);
            cexio_helper_1.cexioEmitter.on('new-trade', cexNewTradeHandler);
            cexio_helper_1.cexioEmitter.on('auth', cexAuthHandler);
            cexio_helper_1.wsCexioAuth(data);
        }
        catch (e) {
            return [2 /*return*/, { error: e }];
        }
        return [2 /*return*/];
    });
}); });
electron_1.ipcMain.handle('getOpenOrdersCexio', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, cexio_helper_1.getOpenOrdersCexio(data)];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); });
electron_1.ipcMain.handle('newOrderCexio', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, cexio_helper_1.newOrderCexio(data)];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); });
electron_1.ipcMain.handle('cancelOrderCexio', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, cexio_helper_1.cancelOrderCexio(data)];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); });
electron_1.ipcMain.handle('closeCexio', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        cexio_helper_1.closeCexio();
        return [2 /*return*/];
    });
}); });
/* //cexio */
electron_1.ipcMain.handle('zbSignature', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        try {
            return [2 /*return*/, zb_helper_1.signature_Zb(data)];
        }
        catch (e) {
            console.error('starting finished with error ', e);
            return [2 /*return*/, { error: e }];
        }
        finally {
            console.log('finalizing crypto');
        }
        return [2 /*return*/];
    });
}); });
electron_1.ipcMain.handle('bittrexRestSignature', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        return [2 /*return*/, bittrex_helper_1.bittrex_RestSignature(data)];
    });
}); });
electron_1.ipcMain.handle('connectBittrex', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    var con;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, bittrex_helper_1.bittrex_Connect(data)];
            case 1:
                con = _a.sent();
                return [2 /*return*/, con];
        }
    });
}); });
function bittrexExecutionHandler(info) {
    win.webContents.send('bittrex-execution', info);
}
function bittrexOrderChangeHandler(info) {
    win.webContents.send('bittrex-order', info);
}
function bittrexBalanceHandler(info) {
    win.webContents.send('bittrex-balance', info);
}
electron_1.ipcMain.handle('authenticateBittrex', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                bittrex_helper_1.bittrexEmitter.off('bittrex-execution', bittrexExecutionHandler);
                bittrex_helper_1.bittrexEmitter.off('bittrex-order', bittrexOrderChangeHandler);
                bittrex_helper_1.bittrexEmitter.off('bittrex-balance', bittrexBalanceHandler);
                bittrex_helper_1.bittrexEmitter.on('bittrex-execution', bittrexExecutionHandler);
                bittrex_helper_1.bittrexEmitter.on('bittrex-order', bittrexOrderChangeHandler);
                bittrex_helper_1.bittrexEmitter.on('bittrex-balance', bittrexBalanceHandler);
                return [4 /*yield*/, bittrex_helper_1.bittrex_Authenticate(data)];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); });
electron_1.ipcMain.handle('closeBittrex', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        bittrex_helper_1.closeBittrex();
        return [2 /*return*/];
    });
}); });
/* coinbase */
electron_1.ipcMain.handle('coinbaseSignature', function (_, data) { return __awaiter(void 0, void 0, void 0, function () {
    var method, path_1, secretKey, timestamp, body, info, what, key, hmac, sign;
    return __generator(this, function (_a) {
        try {
            console.log('data', data);
            method = data.method;
            path_1 = data.path;
            secretKey = data.secretKey;
            timestamp = Date.now() / 1000;
            body = '';
            info = data.data;
            if (method === 'POST' && info) {
                body = JSON.stringify(info);
            }
            what = timestamp + method.toUpperCase() + path_1 + body;
            console.log('what', what);
            key = Buffer.from(secretKey, 'base64');
            hmac = crypto.createHmac('sha256', key);
            sign = hmac.update(what).digest('base64');
            return [2 /*return*/, { sign: sign, timestamp: timestamp }];
        }
        catch (e) {
            // console.error('starting finished with error ', e);
            return [2 /*return*/, { error: e }];
        }
        finally {
            console.log('finalizing crypto');
        }
        return [2 /*return*/];
    });
}); });
/* //coinbase */
//# sourceMappingURL=main.js.map