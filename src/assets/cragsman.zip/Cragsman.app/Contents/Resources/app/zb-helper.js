"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.signature_Zb = void 0;
var crypto = require('crypto');
function signature_Zb(data) {
    try {
        console.log(data);
        var sha1sum = crypto.createHash('sha1');
        sha1sum.update(data.secretKey);
        var hash = sha1sum.digest('hex');
        return crypto.createHmac('md5', hash)
            .update(data.msg)
            .digest('hex');
    }
    catch (e) {
        console.error('starting finished with error ', e);
        return { error: e };
    }
    finally {
        console.log('finalizing crypto');
    }
}
exports.signature_Zb = signature_Zb;
;
//# sourceMappingURL=zb-helper.js.map