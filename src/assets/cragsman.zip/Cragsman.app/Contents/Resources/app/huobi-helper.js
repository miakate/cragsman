"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.signature_V2_Huobi = exports.signature_Huobi = exports.signatureSHA = void 0;
var CryptoJS = require("crypto-js");
var url = require("url");
var moment = require("moment");
/**
 * @param method
 * @param fullURL
 * @param secretKey
 * @param data
 * @returns {*|string}
 */
function signatureSHA(method, fullURL, secretKey, data) {
    var pars = [];
    var _a = url.parse(fullURL), host = _a.host, pathname = _a.pathname;
    for (var key in data) {
        if (Object.prototype.hasOwnProperty.call(data, key)) {
            var value = data[key];
            pars.push(key + "=" + encodeURIComponent(value));
        }
    }
    var p = pars.sort().join("&");
    var meta = [method, host, pathname, p].join('\n');
    var hash = CryptoJS.HmacSHA256(meta, secretKey);
    var signature = CryptoJS.enc.Base64.stringify(hash);
    return signature;
}
exports.signatureSHA = signatureSHA;
/**
 * @param method
 * @param fullURL
 * @param access_key
 * @param secretKey
 * @param data
 */
function signature_Huobi(method, fullURL, access_key, secretKey, data) {
    if (data === void 0) { data = {}; }
    var timestamp = moment().utc().format('YYYY-MM-DDTHH:mm:ss');
    var body = __assign({ AccessKeyId: access_key, SignatureMethod: "HmacSHA256", SignatureVersion: "2", Timestamp: timestamp }, data);
    Object.assign(body, {
        Signature: signatureSHA(method, fullURL, secretKey, body),
    });
    return body;
}
exports.signature_Huobi = signature_Huobi;
/**
 * @param method
 * @param curl
 * @param access_key
 * @param secretKey
 * @param data
 */
function signature_V2_Huobi(method, curl, access_key, secretKey, data) {
    if (data === void 0) { data = {}; }
    var timestamp = moment().utc().format('YYYY-MM-DDTHH:mm:ss');
    var body = __assign({ accessKey: access_key, signatureMethod: "HmacSHA256", signatureVersion: "2.1", timestamp: timestamp }, data);
    Object.assign(body, {
        signature: signatureSHA(method, curl, secretKey, body)
    });
    return body;
}
exports.signature_V2_Huobi = signature_V2_Huobi;
//# sourceMappingURL=huobi-helper.js.map